/* ************************************************
** DO NOT MODIFY OR DISABLE THIS JAVASCRIPT.
** IT IS ESSENTIAL FOR UPDATING YOUR FORUM THEME.
** FORUMACTIF EDGE (https://github.com/SethClydesdale/forumactif-edge)
**************************************************/
window.forumactif_edge_version_data = [
  '1.0.0-beta',
  '1.0.0-beta.1',
  '1.0.0',
  '1.0.1',
  '1.0.2',
  '1.1.0',
  '1.1.1',
  '1.1.2'
];
